module.exports = {
	port: 2000,
	mongodb: 'mongodb://localhost/scms'
}